import React, { Component } from 'react';
import { Text, View } from 'react-native';
class AboutScreen extends Component{
 render(){
 return(
 <View>
 <Text>About</Text>
 </View>
 );
 }
}
export default AboutScreen;